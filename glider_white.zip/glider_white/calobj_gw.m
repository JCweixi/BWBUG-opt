function Y = calobj_gw(s,L,D)
NumSec = 51;
alfa = 6;
for i = 1:size(s,1) 
    num=5;
    xx = [s(i,1:5), 0,0, s(i,1+num),0,  s(i,4+num)+s(i,2+num),s(i,5+num)+(s(i,3+num)*s(i,2+num)/(1-s(i,4+num))), s(i,4+num),s(i,5+num), 1,s(i,5+num)+s(i,3+num), 1,s(i,5+num)+s(i,6+num)+s(i,3+num), s(i,4+num)+s(i,7+num),s(i,5+num)+s(i,8+num), s(i,4+num)+s(i,7+num)+s(i,9+num),s(i,5+num)+s(i,8+num)+(s(i,9+num)*(s(i,6+num)-s(i,8+num)+s(i,3+num))/(1-s(i,4+num)-s(i,7+num))), s(i,10+num),1+s(i,11+num), 0,1, L,D,s(end)];
    Y(i,:) = obj_gw(xx,NumSec,alfa);
end