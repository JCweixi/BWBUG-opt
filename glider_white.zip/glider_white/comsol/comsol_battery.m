function V = comsol_battery(L)
%
% comsol_battery.m
%
% Model exported on Dec 15 2021, 18:56 by COMSOL 5.6.0.401.

import com.comsol.model.*
import com.comsol.model.util.*

model = ModelUtil.create('Model');

model.modelPath('E:\Grey_global_paper\glider_white\comsol');

model.component.create('comp1', true);

model.component('comp1').geom.create('geom1', 3);

model.component('comp1').mesh.create('mesh1');

model.component('comp1').geom('geom1').create('imp1', 'Import');
model.component('comp1').geom('geom1').feature('imp1').set('filename', 'E:\Grey_global_paper\glider_white\comsol\Glider.x_t');
model.component('comp1').geom('geom1').feature('imp1').importData;
model.component('comp1').geom('geom1').run('imp1');
model.component('comp1').geom('geom1').create('uni1', 'Union');
model.component('comp1').geom('geom1').feature('uni1').selection('input').set({'imp1'});
model.component('comp1').geom('geom1').run('uni1');
model.component('comp1').geom('geom1').create('blk1', 'Block');
model.component('comp1').geom('geom1').feature('blk1').set('pos', [-4 -5 -10]);
model.component('comp1').geom('geom1').feature('blk1').set('size', [18 10 10+L]);
model.component('comp1').geom('geom1').run('blk1');
model.component('comp1').geom('geom1').create('dif1', 'Difference');
model.component('comp1').geom('geom1').feature('dif1').selection('input').set({'uni1'});
model.component('comp1').geom('geom1').feature('dif1').selection('input2').set({'blk1'});
model.component('comp1').geom('geom1').run('dif1');

model.component('comp1').geom('geom1').run;
model.component('comp1').geom('geom1').run('fin');

model.component('comp1').geom('geom1').measure.selection.init(3);
model.component('comp1').geom('geom1').measure.selection.all('fin');
V_half =model.component('comp1').geom('geom1').measure().getVolume();
V=2*V_half;
