function V = comsol_layout
%
% comsol_51.m
%
% Model exported on Jul 4 2021, 20:04 by COMSOL 5.6.

import com.comsol.model.*
import com.comsol.model.util.*

model = ModelUtil.create('Model');

model.modelPath('E:\Grey_global_paper\glider_white\comsol');

model.component.create('comp1', true);

model.component('comp1').geom.create('geom1', 3);

model.component('comp1').mesh.create('mesh1');

model.component('comp1').geom('geom1').lengthUnit('m');

model.component('comp1').geom('geom1').create('imp1', 'Import');
model.component('comp1').geom('geom1').feature('imp1').set('filename', 'E:\Grey_global_paper\glider_white\comsol\Glider.x_t');
model.component('comp1').geom('geom1').feature('imp1').importData;
model.component('comp1').geom('geom1').run('imp1');
model.component('comp1').geom('geom1').create('imp2', 'Import');
model.component('comp1').geom('geom1').feature('imp2').set('filename', 'E:\Grey_global_paper\glider_white\comsol\layout.x_t');
model.component('comp1').geom('geom1').feature('imp2').importData;
model.component('comp1').geom('geom1').run('imp2');
model.component('comp1').geom('geom1').create('uni1', 'Union');
model.component('comp1').geom('geom1').feature('uni1').selection('input').set({'imp1' 'imp2'});
model.component('comp1').geom('geom1').run('uni1');

model.component('comp1').geom('geom1').run;
model.component('comp1').geom('geom1').run('fin');

model.component('comp1').geom('geom1').measure.selection.init(3);
model.component('comp1').geom('geom1').measure.selection.all('fin');
V =model.component('comp1').geom('geom1').measure().getVolume();

