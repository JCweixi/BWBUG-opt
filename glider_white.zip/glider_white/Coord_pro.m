function [z,y,c] = Coord_pro(z,UbLine,LbLine)
format long;
c=[];%Chord length transformation
y=[];%Y-direction transformation value
UbLinedata = UbLine;
LbLinedata = LbLine;
for i =1:length(z)
[value,position] = sort(abs(UbLinedata(:,1)-z(i)));
[value1,position1] = sort(abs(LbLinedata(:,1)-z(i)));
z(i) = UbLinedata(position(1),1);
y(i) = UbLinedata(position(1),2);
c(i) = LbLinedata(position1(1),2)-UbLinedata(position(1),2);
end

end