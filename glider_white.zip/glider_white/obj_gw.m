function obj = obj_gw(x,NumberSec,angle)
clc
format short;
global modelnum;

try
    Volume = model_pro(x,NumberSec);
    Volume_layout = comsol_layout;
    con = (Volume_layout-Volume);
    if modelnum == 1
       gwhite_mesh(angle);
    elseif modelnum == 2
       comsol_mesh(angle);
    end
end

if exist('E:\Grey_global_paper\glider_white\comsol\gwhite.nas','file')
    !(E:\Grey_global_paper\glider_white\Fluent\check.bat);
    d001 = importdata('E:\Grey_global_paper\glider_white\Fluent\001');
    data001 = getfield (d001, 'data'); k001f=isempty(find(data001(:,2)>0)); k001z=isempty(find(data001(:,2)<0)); num001=length(unique(data001(:,2)));
    d005 = importdata('E:\Grey_global_paper\glider_white\Fluent\005');
    data005 = getfield (d005, 'data'); k005f=isempty(find(data005(:,2)>0)); k005z=isempty(find(data005(:,2)<0)); num005=length(unique(data005(:,2)));
    d006 = importdata('E:\Grey_global_paper\glider_white\Fluent\006');
    data006 = getfield (d006, 'data'); k006f=isempty(find(data006(:,2)>0)); k006z=isempty(find(data006(:,2)<0)); num006=length(unique(data006(:,2)));
    d007 = importdata('E:\Grey_global_paper\glider_white\Fluent\007');
    data007 = getfield (d007, 'data'); k007f=isempty(find(data007(:,2)>0)); k007z=isempty(find(data007(:,2)<0)); num007=length(unique(data007(:,2)));
    d008 = importdata('E:\Grey_global_paper\glider_white\Fluent\008');
    data008 = getfield (d008, 'data'); k008f=isempty(find(data008(:,2)>0)); k008z=isempty(find(data008(:,2)<0)); num008=length(unique(data008(:,2)));
    d009 = importdata('E:\Grey_global_paper\glider_white\Fluent\009');
    data009 = getfield (d009, 'data'); k009f=isempty(find(data009(:,2)>0)); k009z=isempty(find(data009(:,2)<0)); num009=length(unique(data009(:,2)));
    d010 = importdata('E:\Grey_global_paper\glider_white\Fluent\010');
    data010 = getfield (d010, 'data'); k010f=isempty(find(data010(:,2)>0)); k010z=isempty(find(data010(:,2)<0)); num010=length(unique(data010(:,2)));

    if k001f && num001 == 1
        inlet = 1;
    elseif k005f && num005 == 1 
        inlet = 5;
    elseif k006f && num006 == 1 
        inlet = 6;
    elseif k007f && num007 == 1 
        inlet = 7;
    elseif k008f && num008 == 1 
        inlet = 8;
    elseif k009f && num009 == 1 
        inlet = 9;
    elseif k010f && num010 == 1 
        inlet = 10;
    end

    if k001z && num001 == 1 
        outlet = 1;
    elseif k005z  && num005 == 1 
        outlet = 5;
    elseif k006z && num006 == 1 
        outlet = 6;
    elseif k007z && num007 == 1 
        outlet = 7;
    elseif k008z && num008 == 1 
        outlet = 8;
    elseif k009z && num009 == 1 
        outlet = 9;
    elseif k010z && num010 == 1 
        outlet = 10;
    end

    if size(data001,1)>size(data005,1) && size(data001,1)>size(data006,1) && size(data001,1)>size(data007,1) && size(data001,1)>size(data008,1) && size(data001,1)>size(data009,1) && size(data001,1)>size(data010,1)
        glider = 1;
    elseif size(data005,1)>size(data001,1) && size(data005,1)>size(data006,1) && size(data005,1)>size(data007,1) && size(data005,1)>size(data008,1) && size(data005,1)>size(data009,1) && size(data005,1)>size(data010,1)
        glider = 5;
    elseif size(data006,1)>size(data001,1) && size(data006,1)>size(data005,1) && size(data006,1)>size(data007,1) && size(data006,1)>size(data008,1) && size(data006,1)>size(data009,1) && size(data006,1)>size(data010,1)
        glider = 6;
    elseif size(data007,1)>size(data001,1) && size(data007,1)>size(data005,1) && size(data007,1)>size(data006,1) && size(data007,1)>size(data008,1) && size(data007,1)>size(data009,1) && size(data007,1)>size(data010,1)
        glider = 7;
    elseif size(data008,1)>size(data001,1) && size(data008,1)>size(data005,1) && size(data008,1)>size(data006,1) && size(data008,1)>size(data007,1) && size(data008,1)>size(data009,1) && size(data008,1)>size(data010,1)
        glider = 8;
    elseif size(data009,1)>size(data001,1) && size(data009,1)>size(data005,1) && size(data009,1)>size(data006,1) && size(data009,1)>size(data007,1) && size(data009,1)>size(data008,1) && size(data009,1)>size(data010,1)
        glider = 9;
    elseif size(data010,1)>size(data001,1) && size(data010,1)>size(data005,1) && size(data010,1)>size(data006,1) && size(data010,1)>size(data007,1) && size(data010,1)>size(data008,1) && size(data010,1)>size(data009,1)
        glider = 10;
    end  

    wall=setdiff([1,5,6,7,8,9,10],[inlet,outlet,glider]);
    change_jou(inlet,outlet,wall,glider);
    !(E:\Grey_global_paper\glider_white\Fluent\fluent.bat);

    resuL=importdata('E:\Grey_global_paper\glider_white\comsol\lift-rfile.out');
    resuD=importdata('E:\Grey_global_paper\glider_white\comsol\drag-rfile.out');
    LD=resuL.data(end,2)/resuD.data(end,2);   
    !(E:\Grey_global_paper\glider_white\Fluent\fluent_delete.bat);

    Volume_battery = comsol_battery(x(24)*x(end-2));

    obj = [LD,Volume_battery,con];
else
    obj = [10000000000000000000,10000000000000000000,10000000000000000000];
end






