%Platform

clc
clear

L = 5;% Half spread length
D = 4;% Chord length

range= Range;% Shape range

%optimization
% S_white = rlhsamp(500,length(range),range);
% save('E:\Grey_global_paper\glider_white\S_white.mat','S_white');
% save('E:\Grey_global_paper\glider_white\S_white.txt','S_white','-ASCII');
% S_white = [-0.0300000000000000,-0.0400000000000000,-0.0500000000000000,0.0200000000000000,-0.0100000000000000,0.143000000000000,-0.194500000000000,0.440000000000000,0.300000000000000,0.280000000000000,0.100000000000000,0.140000000000000,0.520000000000000,-0.128000000000000,0.131300000000000,0,0.210000000000000];
S_white = importdata('S_white.mat');
Y = importdata('Y_white.mat');

for i=455:size(S_white,1)
   
   Y(i,:) = calobj_gw(S_white(i,:),L,D);  
   save('E:\Grey_global_paper\glider_white\Y_white.mat','Y');
   save('E:\Grey_global_paper\glider_white\Y_white.txt','Y','-ASCII');

end

      
      
      
      
      
      
      
      
      
