function V = model_pro(x,NumberSec)

Lmiddle = x(18);

switch NumberSec
    case 51
        str = 20;
        z = [0,Lmiddle/30,2*Lmiddle/30,3*Lmiddle/30,4*Lmiddle/30,5*Lmiddle/30,6*Lmiddle/30,7*Lmiddle/30,8*Lmiddle/30,9*Lmiddle/30,10*Lmiddle/30,11*Lmiddle/30,12*Lmiddle/30,13*Lmiddle/30,14*Lmiddle/30,15*Lmiddle/30,16*Lmiddle/30,17*Lmiddle/30,18*Lmiddle/30,19*Lmiddle/30,20*Lmiddle/30,21*Lmiddle/30,22*Lmiddle/30,23*Lmiddle/30,24*Lmiddle/30,25*Lmiddle/30,26*Lmiddle/30,27*Lmiddle/30,28*Lmiddle/30,29*Lmiddle/30,Lmiddle,Lmiddle+(1-Lmiddle)/20,Lmiddle+(1-Lmiddle)*2/20,Lmiddle+(1-Lmiddle)*3/20,Lmiddle+(1-Lmiddle)*4/20,Lmiddle+(1-Lmiddle)*5/20,Lmiddle+(1-Lmiddle)*6/20,Lmiddle+(1-Lmiddle)*7/20,Lmiddle+(1-Lmiddle)*8/20,Lmiddle+(1-Lmiddle)*9/20,Lmiddle+(1-Lmiddle)*10/20,Lmiddle+(1-Lmiddle)*11/20,Lmiddle+(1-Lmiddle)*12/20,Lmiddle+(1-Lmiddle)*13/20,Lmiddle+(1-Lmiddle)*14/20,Lmiddle+(1-Lmiddle)*15/20,Lmiddle+(1-Lmiddle)*16/20,Lmiddle+(1-Lmiddle)*17/20,Lmiddle+(1-Lmiddle)*18/20,Lmiddle+(1-Lmiddle)*19/20,1];                                 
        model_adjust_y(x,str,z);% Same control point, adjust y
        V = comsol_51_1duan;
    otherwise
        disp('Error！！！');
end
end
        