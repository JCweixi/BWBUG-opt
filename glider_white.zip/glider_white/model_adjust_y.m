function model_adjust_y(x,str,z)
global L D P1_x P1_y P2_x P2_y P3_x P3_y P4_x P4_y P5_x P5_y P6_x P6_y P7_x P7_y P8_x P8_y P9_x P9_y P10_x P10_y
L = x(end-2);
D = x(end-1);
P1_x = x(6);
P1_y = x(7);
P2_x = x(8);
P2_y = x(9);
P3_x = x(10);
P3_y = x(11);
P4_x = x(12);
P4_y = x(13);
P5_x = x(14);
P5_y = x(15);
P6_x = x(16);
P6_y = x(17);
P7_x = x(18);
P7_y = x(19);
P8_x = x(20);
P8_y = x(21);
P9_x = x(22);
P9_y = x(23);
P10_x = x(24);
P10_y = x(25);

UbLine = Ubbess_pro;
LbLine = Lbbess_pro;
mm = find(z==P7_x);
zz = z.*L;
[zzz,yy,c] = Coord_pro(zz,UbLine,LbLine);

for i=1:length(z)
    CST_get(x(1:5),str,zzz(i),yy(i),c(i),i,x(end));
end

% Airfoil incompatibility, gradual deformation
CST_get(x(1:5),str,zzz(mm),yy(mm),c(mm),999,x(end));% NACA shape at fusion, label 999
global shape999
shape999=load('E:\Grey_global_paper\glider_white\data\999_Sec.dat');
shape999=shape999./c(mm);% normalization
shape1=load('E:\Grey_global_paper\glider_white\data\1_Sec.dat');

% After adjustment, adjust the relative thickness.
q = linspace(0,1,31);
xd = [];
yd = [];

thicknum1 = 0.025;

dpoint1 = [0,max(shape1(:,2))];
dpoint2 = [P4_x*L*1/3,max(shape1(:,2))];
dpoint3 = [P4_x*L*2/3*2,(max(shape999(:,2))*c(mm)-thicknum1)*P4_x/(3*(1-P4_x))+max(shape999(:,2))*c(mm)];% Point 3 is on the slash
dpoint4 = [P4_x*L*2,max(shape999(:,2))*c(mm)];
for i =1:length(q)% Real space
    t = q(i); 
    xd(i,1) = dpoint1(1)*((1-t)^3)+3*dpoint2(1)*t*((1-t)^2)+3*dpoint3(1)*(t^2)*(1-t)+dpoint4(1)*(t^3);
    yd(i,1) = dpoint1(2)*((1-t)^3)+3*dpoint2(2)*t*((1-t)^2)+3*dpoint3(2)*(t^2)*(1-t)+dpoint4(2)*(t^3);
end

for i=1:mm    
    type1 = '_Sec.dat';
    ii = num2str(i);
    modify_sec = [ii,type1];
    sec_data1 = load(modify_sec);
    datachange1 = sec_data1(:,2);
    % Adjusting relative thickness in real space
    datachange2=datachange1./(max(datachange1)-min(datachange1)).*yd(i,1).*2;
    savedata = [sec_data1(:,1),datachange2,sec_data1(:,3)];
    save(['E:\Grey_global_paper\glider_white\data\',ii,'_Secc','.dat'],'savedata','-ASCII');
end

for i=mm+1:51
    type1 = '_Sec.dat';
    ii = num2str(i);
    modify_sec = [ii,type1];
    sec_data1 = load(modify_sec);
    datachange1 = sec_data1(:,2);
    % Adjusting relative thickness in real space
    datachange2=datachange1./max(datachange1).*(max(shape999(:,2))*c(mm)+(thicknum1-max(shape999(:,2))*c(mm))*((i-mm)/(66-mm)));% The maximum thickness gradually decreases to 4cm
    savedata = [sec_data1(:,1),datachange2,sec_data1(:,3)];
    save(['E:\Grey_global_paper\glider_white\data\',ii,'_Secc','.dat'],'savedata','-ASCII');
end

edgemax=0.005;
for i=1:51
    type1 = '_Secc.dat';
    ii = num2str(i);
    modify_sec = [ii,type1];
    sec_data1 = load(modify_sec);
    %Adjust
    edgenum=find(abs(sec_data1(:,2))>=edgemax);
    file_a=sec_data1(edgenum(1):(72-edgenum(1)),:);
    file_route=[(file_a(:,1)-file_a(37-edgenum(1),1)).*((sec_data1(1,1)-sec_data1(36,1))/(file_a(1,1)-file_a(37-edgenum(1),1)))+file_a(37-edgenum(1),1),file_a(:,2:3)];
    file_route(1,2)=edgemax;file_route(end,2)=-edgemax;
    save(['E:\Grey_global_paper\glider_white\data\',ii,'_Secnew','.dat'],'file_route','-ASCII');
end



