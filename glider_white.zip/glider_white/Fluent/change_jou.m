function change_jou(inlet,outlet,wall,glider)
fid=fopen('E:\Grey_global_paper\glider_white\Fluent\fluent.jou');             
count=1;
str=[];

while ~feof(fid)                
    tline=fgetl(fid);
    str{count}=tline;
    count=count+1;
end
fclose(fid);
%
if inlet == 10
    str{58}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:0',num2str(inlet),' (wall, id=',num2str(inlet),')"))'];
elseif inlet == 1
    str{58}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1 (wall, id=3)"))'];
else
    str{58}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:00',num2str(inlet),' (wall, id=',num2str(inlet),')"))'];
end

if outlet == 10
    str{85}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:0',num2str(outlet),' (wall, id=',num2str(outlet),')"))'];
elseif outlet == 1
    str{85}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1 (wall, id=3)"))'];
else
    str{85}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:00',num2str(outlet),' (wall, id=',num2str(outlet),')"))'];
end

if wall(1) == 10
    str{116}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:0',num2str(wall(1)),' (wall, id=',num2str(wall(1)),')"))'];
elseif wall(1) == 1
    str{116}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1 (wall, id=3)"))'];
else
    str{116}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:00',num2str(wall(1)),' (wall, id=',num2str(wall(1)),')"))'];
end

if wall(2) == 10
    str{157}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:0',num2str(wall(2)),' (wall, id=',num2str(wall(2)),')"))'];
elseif wall(2) == 1
    str{157}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1 (wall, id=3)"))'];
else
    str{157}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:00',num2str(wall(2)),' (wall, id=',num2str(wall(2)),')"))'];
end

if wall(3) == 10
    str{198}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:0',num2str(wall(3)),' (wall, id=',num2str(wall(3)),')"))'];
elseif wall(3) == 1
    str{198}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1 (wall, id=3)"))'];
else
    str{198}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:00',num2str(wall(3)),' (wall, id=',num2str(wall(3)),')"))'];
end

if wall(4) == 10
    str{239}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:0',num2str(wall(4)),' (wall, id=',num2str(wall(4)),')"))'];
elseif wall(4) == 1
    str{239}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1 (wall, id=3)"))'];
else
    str{239}=['(cx-gui-do cx-set-list-tree-selections "NavigationPane*List_Tree1" (list "Setup|Boundary Conditions|Wall|default_exterior-1:00',num2str(wall(4)),' (wall, id=',num2str(wall(4)),')"))'];
end

if glider~=1
    report=setdiff([1,5,6,7,8,9,10],[inlet,outlet]);
    reportnum=find(report==glider)-1;
    str{302}=['(cx-gui-do cx-set-list-selections "Lift Report Definition*Table1*Table2*List2(Zones)" ''','( ',num2str(reportnum),'))'];
    str{311}=['(cx-gui-do cx-set-list-selections "Drag Report Definition*Table1*Table2*List2(Zones)" ''','( ',num2str(reportnum),'))'];
else
    str{302}=['(cx-gui-do cx-set-list-selections "Lift Report Definition*Table1*Table2*List2(Zones)" ''','( ',num2str(0),'))'];
    str{311}=['(cx-gui-do cx-set-list-selections "Drag Report Definition*Table1*Table2*List2(Zones)" ''','( ',num2str(0),'))'];
end
    
fid=fopen('E:\Grey_global_paper\glider_white\Fluent\fluent.jou','w');
for j=1:(count-1)
    fprintf(fid,'%s\r\n',str{j});
end
fclose(fid);   