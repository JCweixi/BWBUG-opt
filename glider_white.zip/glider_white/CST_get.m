function CST_get(t,str,z,xx,c,i,xend)
%----------------------Symmetrical airfoil parameters------------------------------%
d={t(1),t(2),t(3),t(4),t(5)};
[a0,a1,a2,a3,a4]=d{:};
%-------------Define type function--------------------------%
cx=inline('(x.^0.5).*(1-x)','x');
%-------------                                 -------------%
f0=inline('(1-x).^4','x');
f1=inline('4*x.*(1-x).^3','x');
f2=inline('6*(x.^2).*(1-x).^2','x');
f3=inline('4*(x.^3).*(1-x)','x');
f4=inline('x.^4','x');
%-------------Import initial base airfoil value points--------------------------%
type1 = '.dat';
type2 = 'naca00';
str = num2str(str);
i = num2str(i);
Airfoil = [type2,str,type1];
Foildata = load(Airfoil);
x=Foildata(:,1);
y=Foildata(:,2);
n=length(x);
xup=x(1:1:(n+1)/2);
xdn=x((n+1)/2+1:1:n);
%---------------------------------------%
yup=y(1:1:(n+1)/2);
ydn=y((n+1)/2+1:1:n);
%------------------------------------%
Su=a0*f0(xup)+a1*f1(xup)+a2*f2(xup)+a3*f3(xup)+a4*f4(xup);
Sl=-a0*f0(xdn)-a1*f1(xdn)-a2*f2(xdn)-a3*f3(xdn)-a4*f4(xdn);
%--------------------------------%
dyup=cx(xup).*Su;
dydn=cx(xdn).*Sl;
yu=yup+dyup;
yl=ydn+dydn;

yu((n+1)/2)=[];
ym=(yu+yl)/2;
yh=abs(yu-yl)/2;
yu=ym+yh;
yl=ym-yh;
yy=[yu;0;yl];
    data = [x,yy];
    Number1 = ones(size(data,1),1);
    Sec(:,1)=c*data(:,1)+xx;
    Sec(:,2)=(c*xend/2)/max(data(:,2))*data(:,2);
    Sec(:,3)=Number1.*z;
    file_route = 'E:\Grey_global_paper\glider_white\data\';
    save([file_route,i,'_Sec','.dat'],'Sec','-ASCII');
        
end