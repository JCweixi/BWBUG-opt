function data = Ubbess_pro
%Profile leading edge line
global L D P1_x P1_y P2_x P2_y P3_x P3_y P4_x P4_y P5_x P5_y P6_x P6_y P7_x P7_y P8_x P8_y P9_x P9_y P10_x P10_y
q = linspace(0,1,500);
x1 = [];
y1 = [];
x2 = [];
y2 = [];
xx = [];
for i =1:length(q)
    t = q(i); 
    x1(i,1) = P1_x*((1-t)^3)+3*P2_x*t*((1-t)^2)+3*P3_x*(t^2)*(1-t)+P4_x*(t^3);
    y1(i,1) = P1_y*((1-t)^3)+3*P2_y*t*((1-t)^2)+3*P3_y*(t^2)*(1-t)+P4_y*(t^3);
    x2(i,1) = (1-P4_x)*t+P4_x;
    y2(i,1) = (P5_y-P4_y)*t+P4_y;
end
x = [x1;x2];
y = [y1;y2];
xx = x.*L;
yy = y.*D;
Number1 = zeros(length(xx),1);
data = [xx,yy,Number1];
save 'E:\Grey_global_paper\glider_white\data\UbLine.dat' -ascii data;
end