function range=Range

range2 = [-0.0573, -0.0494, -0.0557, -0.0383, -0.0574;
           0.0573,  0.0494,  0.0557,  0.0383,  0.0574]; % Wing NACA14 linetype: CST
       
range3 = [0.05, -0.20,0.06, 0.2,0.16, 0.10, 0.050,0.30, -0.20, 0.04,-0.14;
          0.20, -0.07,0.68, 0.6,0.65, 0.28, 0.198,0.64, -0.04, 0.19,    0]; % Plane shape   
      
range4 = [0.17;0.23];%slenderness ratio
      
range = [range2,range3,range4];

end